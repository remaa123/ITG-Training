# Shopify Inventory Sync (Java / Spring Boot)

A background service that reads warehouse inventory XML files from SFTP and sets absolute Shopify inventory quantities at four Shopify locations: **US, UK, UAE, and EU**.

## 1. What this service uses

- Java 21
- Spring Boot 4.1
- Maven
- Shopify GraphQL Admin API `2026-04`
- Shopify client-credentials grant for a custom app
- SSHJ for SFTP
- StAX for namespace-aware streaming XML parsing
- JUnit 5 tests

This is **not** a Storefront API or Hydrogen task. It is a server-to-server Admin API integration.

## 2. Shopify app setup

Create the app in Shopify's **Dev Dashboard**, configure the minimum Admin API scopes, release the app version, install it on the target store, then copy its Client ID and Client Secret.

Required scopes:

```text
read_products
write_products
read_inventory
write_inventory
read_locations
write_locations
```

Authentication supports two safe server-side options:

1. `SHOPIFY_CLIENT_ID` + `SHOPIFY_CLIENT_SECRET` for an organization-owned app that is eligible for Shopify's client-credentials grant. The service refreshes the 24-hour token automatically.
2. `SHOPIFY_ACCESS_TOKEN` when Shopify gives you an already-issued offline Admin API token through the app installation/OAuth flow.

Do not configure both unless you intentionally want `SHOPIFY_ACCESS_TOKEN` to take priority.

## 3. Catalog prerequisite

Before running `APP_MODE=setup`, import approximately 500 variants through Shopify Admin > Products > Import.

Rules:

- Every variant SKU must exactly equal the XML `product-id`.
- SKU values must be unique.
- Set inventory tracking to Shopify.
- Use a placeholder title if catalog content is unavailable.
- Obtain the real SKU list from the warehouse XML feed; do not invent SKUs.
- Variant metafields are applied by this service after import, not by the standard product CSV.

## 4. Markets and shipping

Locations hold inventory. Markets and shipping settings decide where customers can buy and where orders can be shipped. In Shopify Admin, activate the required countries/markets and configure shipping zones/rates for US, UK, UAE, and the intended EU countries.

## 5. Configure

```bash
cp .env.example .env
```

Fill all required values. Never commit `.env`.

For SFTP host verification, provide `SFTP_KNOWN_HOSTS_PATH`. Only use `SFTP_ALLOW_INSECURE_HOST_KEY=true` against a local test server.

## 6. Run from IntelliJ IDEA

1. Install IntelliJ IDEA Community Edition and JDK 21.
2. Open the folder as a Maven project.
3. Wait for Maven dependencies to load.
4. Copy `.env.example` to `.env` and fill it.
5. Run `ShopifyInventorySyncApplication`.

Or from a terminal:

```bash
mvn test
mvn spring-boot:run
```

### Setup mode (one time after product import)

```env
APP_MODE=setup
```

It will:

1. Resolve or create the four Shopify locations.
2. Create the variant JSON metafield definition.
3. Load variants and build the SKU map.
4. Apply the default all-online metafield when it is missing.
5. Enable inventory tracking when needed.
6. Activate every inventory item at all four locations.

### One manual sync

```env
APP_MODE=sync-once
```

### Hourly scheduler

```env
APP_MODE=scheduler
SYNC_CRON=0 0 * * * *
```

## 7. File processing sequence

For every warehouse:

1. List only files matching the exact warehouse filename regex.
2. Sort files by timestamped filename.
3. Download a remote file to the local work directory.
4. Parse `product-id` and `allocation` using namespace-aware XML parsing.
5. Normalize negative quantities to zero and skip invalid records.
6. Match XML SKU to Shopify InventoryItem.
7. Apply the regional metafield policy (`EU` reads `Deret`).
8. Send absolute `available` quantities in batches of at most 250.
9. Continue later batches even when one batch fails.
10. Move the remote file to `<source>/processed/` only if every batch for that file succeeds.
11. Delete the local copy only after the remote move succeeds.

The service never deletes a remote SFTP file.

## 8. Important production note

`inventorySetQuantities` is correct here because the warehouse feed is the inventory source of truth. The implementation uses `ignoreCompareQuantity=true`, so only one scheduler instance should run at a time. The in-process lock prevents overlap in one JVM. If deployed as multiple replicas, add a distributed lock or run exactly one replica.

## 9. Tests included

- SFTP filename filtering
- processed-file path handling
- namespace-aware XML parsing
- quantity normalization
- warehouse mapping and EU-to-Deret mapping
- missing/invalid metafield defaults
- offline forced-zero behavior
- 250-item batching
- missing-SKU handling
- duplicate XML SKU behavior
