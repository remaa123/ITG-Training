package com.training.shopifysync.domain;

public record InventoryUpdate(
        WarehouseRegion warehouse,
        String sku,
        String inventoryItemId,
        String locationId,
        int quantity,
        String metafieldValue,
        String policyNote
) {
}
