package com.training.shopifysync.shopify;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.shopifysync.config.ShopifyProperties;
import com.training.shopifysync.exception.ShopifyApiException;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Instant;

@Service
public class ShopifyTokenService {
    private final ShopifyProperties properties;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    private volatile String accessToken;
    private volatile Instant expiresAt = Instant.EPOCH;

    public ShopifyTokenService(ShopifyProperties properties, ObjectMapper objectMapper) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder().build();
    }

    public String getAccessToken() {
        if (properties.hasStaticAccessToken()) {
            return properties.accessToken().trim();
        }
        if (!properties.hasClientCredentials()) {
            throw new ShopifyApiException(
                    "Configure either SHOPIFY_ACCESS_TOKEN or both SHOPIFY_CLIENT_ID and SHOPIFY_CLIENT_SECRET",
                    "unknown"
            );
        }
        if (accessToken == null || Instant.now().isAfter(expiresAt.minusSeconds(300))) {
            synchronized (this) {
                if (accessToken == null || Instant.now().isAfter(expiresAt.minusSeconds(300))) {
                    refreshToken();
                }
            }
        }
        return accessToken;
    }

    private void refreshToken() {
        String form = "grant_type=client_credentials"
                + "&client_id=" + encode(properties.clientId())
                + "&client_secret=" + encode(properties.clientSecret());
        URI uri = URI.create("https://" + properties.normalizedShop() + "/admin/oauth/access_token");
        HttpRequest request = HttpRequest.newBuilder(uri)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form))
                .build();
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            String requestId = response.headers().firstValue("x-request-id").orElse("unknown");
            if (response.statusCode() / 100 != 2) {
                throw new ShopifyApiException(
                        "Unable to obtain Shopify access token. HTTP " + response.statusCode() + ": " + response.body(),
                        requestId
                );
            }
            JsonNode root = objectMapper.readTree(response.body());
            this.accessToken = root.path("access_token").asText();
            long expiresIn = root.path("expires_in").asLong(86_399L);
            this.expiresAt = Instant.now().plusSeconds(expiresIn);
        } catch (ShopifyApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ShopifyApiException("Unable to obtain Shopify access token", "unknown", e);
        }
    }

    private String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
