package com.training.shopifysync.scheduler;

import com.training.shopifysync.service.InventorySyncService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.mode", havingValue = "scheduler", matchIfMissing = true)
public class InventorySyncScheduler {
    private final InventorySyncService syncService;

    public InventorySyncScheduler(InventorySyncService syncService) {
        this.syncService = syncService;
    }

    @Scheduled(cron = "${sync.cron}", zone = "${sync.zone}")
    public void runHourlySync() {
        syncService.syncAllWarehouses();
    }
}
