package com.training.shopifysync.domain;

public record InventoryRecord(String sku, int quantity) {
}
