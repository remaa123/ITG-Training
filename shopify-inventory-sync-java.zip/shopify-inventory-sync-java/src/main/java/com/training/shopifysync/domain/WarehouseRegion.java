package com.training.shopifysync.domain;

import java.util.Arrays;
import java.util.Optional;
import java.util.regex.Pattern;

public enum WarehouseRegion {
    US("Huda_inv_full_us_", "US"),
    UK("Huda_inv_full_uk_", "UK"),
    UAE("Huda_inv_full_", "UAE"),
    EU("Huda_inv_full_dr_", "Deret");

    private final String prefix;
    private final String metafieldKey;
    private final Pattern filePattern;

    WarehouseRegion(String prefix, String metafieldKey) {
        this.prefix = prefix;
        this.metafieldKey = metafieldKey;
        this.filePattern = Pattern.compile("^" + Pattern.quote(prefix) + "\\d{14}\\.xml$");
    }

    public String prefix() {
        return prefix;
    }

    public String metafieldKey() {
        return metafieldKey;
    }

    public boolean matchesFileName(String fileName) {
        return filePattern.matcher(fileName).matches();
    }

    public static Optional<WarehouseRegion> fromFileName(String fileName) {
        return Arrays.stream(values()).filter(region -> region.matchesFileName(fileName)).findFirst();
    }
}
