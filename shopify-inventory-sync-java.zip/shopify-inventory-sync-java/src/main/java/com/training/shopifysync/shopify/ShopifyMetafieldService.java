package com.training.shopifysync.shopify;

import com.fasterxml.jackson.databind.JsonNode;
import com.training.shopifysync.domain.GraphQlResult;
import com.training.shopifysync.domain.ShopifyVariant;
import com.training.shopifysync.exception.SetupException;
import com.training.shopifysync.util.BatchUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ShopifyMetafieldService {
    private static final Logger log = LoggerFactory.getLogger(ShopifyMetafieldService.class);
    public static final String DEFAULT_VALUE = "{\"US\":true,\"UK\":true,\"UAE\":true,\"Deret\":true}";

    private static final String CREATE_DEFINITION = """
            mutation CreateVariantInventoryPolicyDefinition($definition: MetafieldDefinitionInput!) {
              metafieldDefinitionCreate(definition: $definition) {
                createdDefinition { id name namespace key type { name } }
                userErrors { field message code }
              }
            }
            """;

    private static final String SET_METAFIELDS = """
            mutation SetVariantInventoryPolicies($metafields: [MetafieldsSetInput!]!) {
              metafieldsSet(metafields: $metafields) {
                metafields { id namespace key value }
                userErrors { field message code }
              }
            }
            """;

    private final ShopifyGraphQlClient client;

    public ShopifyMetafieldService(ShopifyGraphQlClient client) {
        this.client = client;
    }

    public void ensureDefinition() {
        Map<String, Object> definition = Map.of(
                "name", "Variant online consolidated JSON",
                "description", "Controls whether this variant is online per warehouse region.",
                "namespace", "custom",
                "key", "variant_online_consolidated_json",
                "type", "json",
                "ownerType", "PRODUCTVARIANT"
        );
        GraphQlResult response = client.execute(CREATE_DEFINITION, Map.of("definition", definition));
        JsonNode errors = response.data().path("metafieldDefinitionCreate").path("userErrors");
        if (errors.isArray() && !errors.isEmpty()) {
            String text = errors.toString().toLowerCase();
            if (text.contains("already") || text.contains("taken") || text.contains("exists")) {
                log.info("Variant metafield definition already exists");
                return;
            }
            throw new SetupException("Unable to create variant metafield definition. errors=" + errors
                    + " requestId=" + response.requestId());
        }
        log.info("Created variant metafield definition custom.variant_online_consolidated_json");
    }

    public void setDefaultForMissing(List<ShopifyVariant> variants) {
        List<ShopifyVariant> missing = variants.stream()
                .filter(v -> v.metafieldValue() == null || v.metafieldValue().isBlank())
                .toList();

        for (List<ShopifyVariant> batch : BatchUtils.partition(missing, 25)) {
            List<Map<String, Object>> inputs = new ArrayList<>();
            for (ShopifyVariant variant : batch) {
                inputs.add(Map.of(
                        "ownerId", variant.variantId(),
                        "namespace", "custom",
                        "key", "variant_online_consolidated_json",
                        "type", "json",
                        "value", DEFAULT_VALUE
                ));
            }
            GraphQlResult response = client.execute(SET_METAFIELDS, Map.of("metafields", inputs));
            JsonNode errors = response.data().path("metafieldsSet").path("userErrors");
            if (errors.isArray() && !errors.isEmpty()) {
                throw new SetupException("Unable to set default variant metafields. errors=" + errors
                        + " requestId=" + response.requestId());
            }
        }
        log.info("Applied default metafield to missing variants count={}", missing.size());
    }
}
