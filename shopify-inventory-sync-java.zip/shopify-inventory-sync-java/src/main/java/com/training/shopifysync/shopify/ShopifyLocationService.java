package com.training.shopifysync.shopify;

import com.fasterxml.jackson.databind.JsonNode;
import com.training.shopifysync.config.SetupProperties;
import com.training.shopifysync.domain.GraphQlResult;
import com.training.shopifysync.domain.WarehouseRegion;
import com.training.shopifysync.exception.SetupException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ShopifyLocationService {
    private static final Logger log = LoggerFactory.getLogger(ShopifyLocationService.class);

    private static final String LOCATIONS_QUERY = """
            query RequiredLocations {
              locations(first: 250, includeInactive: true) {
                nodes { id name isActive fulfillsOnlineOrders }
              }
            }
            """;

    private static final String ADD_LOCATION_MUTATION = """
            mutation AddLocation($input: LocationAddInput!) {
              locationAdd(input: $input) {
                location { id name }
                userErrors { field message code }
              }
            }
            """;

    private final ShopifyGraphQlClient client;
    private final SetupProperties setupProperties;

    public ShopifyLocationService(ShopifyGraphQlClient client, SetupProperties setupProperties) {
        this.client = client;
        this.setupProperties = setupProperties;
    }

    public Map<WarehouseRegion, String> resolveRequiredLocations(boolean createMissing) {
        Map<String, String> existingByName = loadLocationsByName();
        Map<WarehouseRegion, String> resolved = new EnumMap<>(WarehouseRegion.class);
        List<String> missing = new java.util.ArrayList<>();

        for (WarehouseRegion region : WarehouseRegion.values()) {
            String configuredId = trimToNull(setupProperties.value(setupProperties.locationIds(), region));
            if (configuredId != null) {
                resolved.put(region, configuredId);
                continue;
            }
            String expectedName = setupProperties.value(setupProperties.locationNames(), region);
            String foundId = existingByName.get(expectedName);
            if (foundId != null) {
                resolved.put(region, foundId);
            } else if (createMissing) {
                resolved.put(region, createLocation(region, expectedName));
            } else {
                missing.add(expectedName);
            }
        }

        if (!missing.isEmpty()) {
            throw new SetupException("Missing Shopify locations: " + missing
                    + ". Run APP_MODE=setup with write_locations access, or create them manually and set their IDs in .env.");
        }
        return Map.copyOf(resolved);
    }

    private Map<String, String> loadLocationsByName() {
        GraphQlResult response = client.execute(LOCATIONS_QUERY, Map.of());
        Map<String, String> byName = new HashMap<>();
        for (JsonNode node : response.data().path("locations").path("nodes")) {
            byName.put(node.path("name").asText(), node.path("id").asText());
        }
        return byName;
    }

    private String createLocation(WarehouseRegion region, String name) {
        Map<String, Object> address = new HashMap<>();
        putIfPresent(address, "countryCode", setupProperties.value(setupProperties.countryCodes(), region));
        putIfPresent(address, "address1", setupProperties.value(setupProperties.addressLines(), region));
        putIfPresent(address, "city", setupProperties.value(setupProperties.cities(), region));
        putIfPresent(address, "zip", setupProperties.value(setupProperties.postalCodes(), region));

        Map<String, Object> input = new HashMap<>();
        input.put("name", name);
        input.put("address", address);
        input.put("fulfillsOnlineOrders", true);

        GraphQlResult response = client.execute(ADD_LOCATION_MUTATION, Map.of("input", input));
        JsonNode payload = response.data().path("locationAdd");
        JsonNode errors = payload.path("userErrors");
        if (errors.isArray() && !errors.isEmpty()) {
            throw new SetupException("Shopify could not create location '" + name + "'. Errors=" + errors
                    + ". Create it manually or grant write_locations. requestId=" + response.requestId());
        }
        String id = payload.path("location").path("id").asText();
        log.info("Created Shopify location region={} name={} id={}", region, name, id);
        return id;
    }

    private void putIfPresent(Map<String, Object> target, String key, String value) {
        String clean = trimToNull(value);
        if (clean != null) {
            target.put(key, clean);
        }
    }

    private String trimToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }
}
