package com.training.shopifysync.service;

import com.training.shopifysync.domain.InventoryRecord;
import com.training.shopifysync.domain.InventoryUpdate;
import com.training.shopifysync.domain.PlanResult;
import com.training.shopifysync.domain.PolicyDecision;
import com.training.shopifysync.domain.ShopifyVariant;
import com.training.shopifysync.domain.WarehouseRegion;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class InventoryUpdatePlanner {
    private final VariantOnlinePolicy policy;

    public InventoryUpdatePlanner(VariantOnlinePolicy policy) {
        this.policy = policy;
    }

    public PlanResult plan(
            List<InventoryRecord> records,
            Map<String, ShopifyVariant> variantsBySku,
            WarehouseRegion warehouse,
            String locationId
    ) {
        Map<String, InventoryRecord> uniqueRecords = new LinkedHashMap<>();
        int duplicates = 0;
        for (InventoryRecord record : records) {
            if (uniqueRecords.put(record.sku(), record) != null) {
                duplicates++;
            }
        }

        List<InventoryUpdate> updates = new ArrayList<>();
        List<String> missingSkus = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        int forcedZero = 0;

        for (InventoryRecord record : uniqueRecords.values()) {
            ShopifyVariant variant = variantsBySku.get(record.sku());
            if (variant == null) {
                missingSkus.add(record.sku());
                continue;
            }
            PolicyDecision decision = policy.evaluate(variant.metafieldValue(), warehouse);
            int quantity = decision.online() ? record.quantity() : 0;
            if (!decision.online()) {
                forcedZero++;
            }
            if (!"online".equals(decision.note()) && !decision.note().startsWith("offline")) {
                warnings.add("sku=" + record.sku() + " warehouse=" + warehouse + " " + decision.note());
            }
            updates.add(new InventoryUpdate(
                    warehouse,
                    record.sku(),
                    variant.inventoryItemId(),
                    locationId,
                    quantity,
                    variant.metafieldValue(),
                    decision.note()
            ));
        }

        return new PlanResult(
                List.copyOf(updates),
                List.copyOf(missingSkus),
                forcedZero,
                duplicates,
                List.copyOf(warnings)
        );
    }
}
