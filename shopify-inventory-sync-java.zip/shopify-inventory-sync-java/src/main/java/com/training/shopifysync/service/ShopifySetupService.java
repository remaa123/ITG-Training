package com.training.shopifysync.service;

import com.training.shopifysync.domain.ShopifyVariant;
import com.training.shopifysync.domain.WarehouseRegion;
import com.training.shopifysync.shopify.ShopifyCatalogService;
import com.training.shopifysync.shopify.ShopifyInventoryService;
import com.training.shopifysync.shopify.ShopifyLocationService;
import com.training.shopifysync.shopify.ShopifyMetafieldService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ShopifySetupService {
    private static final Logger log = LoggerFactory.getLogger(ShopifySetupService.class);

    private final ShopifyLocationService locationService;
    private final ShopifyMetafieldService metafieldService;
    private final ShopifyCatalogService catalogService;
    private final ShopifyInventoryService inventoryService;

    public ShopifySetupService(
            ShopifyLocationService locationService,
            ShopifyMetafieldService metafieldService,
            ShopifyCatalogService catalogService,
            ShopifyInventoryService inventoryService
    ) {
        this.locationService = locationService;
        this.metafieldService = metafieldService;
        this.catalogService = catalogService;
        this.inventoryService = inventoryService;
    }

    public void runSetup() {
        log.info("Starting Shopify one-time setup");
        Map<WarehouseRegion, String> locations = locationService.resolveRequiredLocations(true);
        metafieldService.ensureDefinition();

        List<ShopifyVariant> variants = catalogService.buildSkuMap().values().stream().toList();
        if (variants.isEmpty()) {
            throw new IllegalStateException("No Shopify variants found. Import the ~500 SKU catalog first, then rerun setup.");
        }

        metafieldService.setDefaultForMissing(variants);
        inventoryService.ensureTrackedAndActivated(variants, locations);

        locations.forEach((region, id) -> log.info("Resolved Shopify location region={} id={}", region, id));
        log.info("Shopify setup finished variants={}", variants.size());
    }
}
