package com.training.shopifysync.domain;

import java.util.List;

public record BatchOutcome(boolean success, String requestId, List<String> errors) {
}
