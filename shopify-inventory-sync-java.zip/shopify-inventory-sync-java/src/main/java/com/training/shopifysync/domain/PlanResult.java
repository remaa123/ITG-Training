package com.training.shopifysync.domain;

import java.util.List;

public record PlanResult(
        List<InventoryUpdate> updates,
        List<String> missingSkus,
        int forcedZeroCount,
        int duplicateXmlSkuCount,
        List<String> policyWarnings
) {
}
