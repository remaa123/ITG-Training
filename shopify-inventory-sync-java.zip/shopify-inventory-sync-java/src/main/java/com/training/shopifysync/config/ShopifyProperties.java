package com.training.shopifysync.config;

import jakarta.validation.constraints.NotBlank;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "shopify")
public record ShopifyProperties(
        @NotBlank String shop,
        String clientId,
        String clientSecret,
        String accessToken,
        @NotBlank String apiVersion
) {
    public String normalizedShop() {
        String value = shop.trim()
                .replace("https://", "")
                .replace("http://", "");
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    public boolean hasStaticAccessToken() {
        return accessToken != null && !accessToken.isBlank();
    }

    public boolean hasClientCredentials() {
        return clientId != null && !clientId.isBlank()
                && clientSecret != null && !clientSecret.isBlank();
    }
}
