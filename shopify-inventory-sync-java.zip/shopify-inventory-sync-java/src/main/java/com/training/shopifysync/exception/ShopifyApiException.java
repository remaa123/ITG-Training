package com.training.shopifysync.exception;

public class ShopifyApiException extends RuntimeException {
    private final String requestId;

    public ShopifyApiException(String message, String requestId) {
        super(message);
        this.requestId = requestId;
    }

    public ShopifyApiException(String message, String requestId, Throwable cause) {
        super(message, cause);
        this.requestId = requestId;
    }

    public String requestId() {
        return requestId;
    }
}
