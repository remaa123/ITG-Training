package com.training.shopifysync.config;

import com.training.shopifysync.domain.WarehouseRegion;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

@ConfigurationProperties(prefix = "setup")
public record SetupProperties(
        Map<WarehouseRegion, String> locationIds,
        Map<WarehouseRegion, String> locationNames,
        Map<WarehouseRegion, String> countryCodes,
        Map<WarehouseRegion, String> addressLines,
        Map<WarehouseRegion, String> cities,
        Map<WarehouseRegion, String> postalCodes
) {
    public String value(Map<WarehouseRegion, String> map, WarehouseRegion region) {
        return map == null ? null : map.get(region);
    }
}
