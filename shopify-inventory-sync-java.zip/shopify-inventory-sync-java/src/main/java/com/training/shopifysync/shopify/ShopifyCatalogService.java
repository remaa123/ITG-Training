package com.training.shopifysync.shopify;

import com.fasterxml.jackson.databind.JsonNode;
import com.training.shopifysync.domain.GraphQlResult;
import com.training.shopifysync.domain.ShopifyVariant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class ShopifyCatalogService {
    private static final Logger log = LoggerFactory.getLogger(ShopifyCatalogService.class);

    private static final String VARIANTS_QUERY = """
            query VariantsForInventory($after: String) {
              productVariants(first: 250, after: $after) {
                nodes {
                  id
                  sku
                  inventoryItem { id tracked }
                  metafield(namespace: "custom", key: "variant_online_consolidated_json") { value }
                }
                pageInfo { hasNextPage endCursor }
              }
            }
            """;

    private final ShopifyGraphQlClient client;

    public ShopifyCatalogService(ShopifyGraphQlClient client) {
        this.client = client;
    }

    public Map<String, ShopifyVariant> buildSkuMap() {
        Map<String, ShopifyVariant> result = new LinkedHashMap<>();
        String after = null;
        boolean hasNext;
        do {
            Map<String, Object> variables = new java.util.HashMap<>();
            variables.put("after", after);
            GraphQlResult response = client.execute(VARIANTS_QUERY, variables);
            JsonNode connection = response.data().path("productVariants");
            for (JsonNode node : connection.path("nodes")) {
                String sku = text(node, "sku");
                if (sku == null || sku.isBlank()) {
                    log.warn("Skipping Shopify variant without SKU variantId={}", text(node, "id"));
                    continue;
                }
                JsonNode inventoryItem = node.path("inventoryItem");
                ShopifyVariant variant = new ShopifyVariant(
                        text(node, "id"),
                        sku.trim(),
                        text(inventoryItem, "id"),
                        inventoryItem.path("tracked").asBoolean(false),
                        node.path("metafield").isMissingNode() || node.path("metafield").isNull()
                                ? null : text(node.path("metafield"), "value")
                );
                ShopifyVariant existing = result.putIfAbsent(variant.sku(), variant);
                if (existing != null) {
                    log.error("Duplicate Shopify SKU detected; keeping first sku={} firstVariantId={} duplicateVariantId={}",
                            sku, existing.variantId(), variant.variantId());
                }
            }
            JsonNode pageInfo = connection.path("pageInfo");
            hasNext = pageInfo.path("hasNextPage").asBoolean(false);
            after = hasNext ? pageInfo.path("endCursor").asText() : null;
        } while (hasNext);

        log.info("Built Shopify SKU map variants={}", result.size());
        return result;
    }

    private String text(JsonNode node, String field) {
        JsonNode value = node.path(field);
        return value.isMissingNode() || value.isNull() ? null : value.asText();
    }
}
