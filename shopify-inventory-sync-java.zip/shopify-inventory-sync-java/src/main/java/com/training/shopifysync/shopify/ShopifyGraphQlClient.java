package com.training.shopifysync.shopify;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.shopifysync.config.ShopifyProperties;
import com.training.shopifysync.domain.GraphQlResult;
import com.training.shopifysync.exception.ShopifyApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

@Component
public class ShopifyGraphQlClient {
    private static final Logger log = LoggerFactory.getLogger(ShopifyGraphQlClient.class);

    private final ShopifyProperties properties;
    private final ShopifyTokenService tokenService;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public ShopifyGraphQlClient(
            ShopifyProperties properties,
            ShopifyTokenService tokenService,
            ObjectMapper objectMapper
    ) {
        this.properties = properties;
        this.tokenService = tokenService;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(20)).build();
    }

    public GraphQlResult execute(String query, Map<String, Object> variables) {
        URI uri = URI.create("https://" + properties.normalizedShop()
                + "/admin/api/" + properties.apiVersion() + "/graphql.json");
        try {
            String body = objectMapper.writeValueAsString(Map.of(
                    "query", query,
                    "variables", variables == null ? Map.of() : variables
            ));

            for (int attempt = 1; attempt <= 4; attempt++) {
                HttpRequest request = HttpRequest.newBuilder(uri)
                        .timeout(Duration.ofSeconds(60))
                        .header("Content-Type", "application/json")
                        .header("X-Shopify-Access-Token", tokenService.getAccessToken())
                        .POST(HttpRequest.BodyPublishers.ofString(body))
                        .build();

                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                String requestId = response.headers().firstValue("x-request-id").orElse("unknown");

                if (response.statusCode() == 429 && attempt < 4) {
                    long waitSeconds = response.headers().firstValue("retry-after")
                            .map(Long::parseLong).orElse(2L * attempt);
                    log.warn("Shopify throttled request; retrying attempt={} waitSeconds={} requestId={}",
                            attempt, waitSeconds, requestId);
                    Thread.sleep(waitSeconds * 1000);
                    continue;
                }

                if (response.statusCode() / 100 != 2) {
                    throw new ShopifyApiException(
                            "Shopify GraphQL HTTP " + response.statusCode() + ": " + response.body(),
                            requestId
                    );
                }

                JsonNode root = objectMapper.readTree(response.body());
                JsonNode errors = root.path("errors");
                if (errors.isArray() && !errors.isEmpty()) {
                    boolean throttled = errors.toString().contains("THROTTLED");
                    if (throttled && attempt < 4) {
                        Thread.sleep(1_000L * attempt);
                        continue;
                    }
                    throw new ShopifyApiException("GraphQL errors: " + errors, requestId);
                }
                return new GraphQlResult(root.path("data"), requestId);
            }
            throw new ShopifyApiException("Shopify request failed after retries", "unknown");
        } catch (ShopifyApiException e) {
            throw e;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ShopifyApiException("Shopify request interrupted", "unknown", e);
        } catch (Exception e) {
            throw new ShopifyApiException("Shopify GraphQL request failed", "unknown", e);
        }
    }
}
