package com.training.shopifysync.config;

import com.training.shopifysync.domain.WarehouseRegion;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.util.Map;

@Validated
@ConfigurationProperties(prefix = "sftp")
public record SftpProperties(
        String host,
        int port,
        String username,
        String password,
        String privateKeyPath,
        String privateKeyPassphrase,
        String knownHostsPath,
        boolean allowInsecureHostKey,
        @NotNull Map<WarehouseRegion, String> directories
) {
}