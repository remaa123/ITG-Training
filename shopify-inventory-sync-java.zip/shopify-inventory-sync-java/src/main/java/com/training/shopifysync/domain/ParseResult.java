package com.training.shopifysync.domain;

import java.util.List;

public record ParseResult(List<InventoryRecord> records, int skippedRecords) {
}
