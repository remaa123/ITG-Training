package com.training.shopifysync.service;

import com.training.shopifysync.config.SyncProperties;
import com.training.shopifysync.domain.BatchOutcome;
import com.training.shopifysync.domain.InventoryUpdate;
import com.training.shopifysync.domain.ParseResult;
import com.training.shopifysync.domain.PlanResult;
import com.training.shopifysync.domain.RemoteInventoryFile;
import com.training.shopifysync.domain.ShopifyVariant;
import com.training.shopifysync.domain.WarehouseRegion;
import com.training.shopifysync.shopify.ShopifyCatalogService;
import com.training.shopifysync.shopify.ShopifyInventoryService;
import com.training.shopifysync.shopify.ShopifyLocationService;
import com.training.shopifysync.util.BatchUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
public class InventorySyncService {
    private static final Logger log = LoggerFactory.getLogger(InventorySyncService.class);

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final SyncProperties syncProperties;
    private final ShopifyLocationService locationService;
    private final ShopifyCatalogService catalogService;
    private final ShopifyInventoryService inventoryService;
    private final SftpService sftpService;
    private final XmlInventoryParser xmlParser;
    private final InventoryUpdatePlanner planner;

    public InventorySyncService(
            SyncProperties syncProperties,
            ShopifyLocationService locationService,
            ShopifyCatalogService catalogService,
            ShopifyInventoryService inventoryService,
            SftpService sftpService,
            XmlInventoryParser xmlParser,
            InventoryUpdatePlanner planner
    ) {
        this.syncProperties = syncProperties;
        this.locationService = locationService;
        this.catalogService = catalogService;
        this.inventoryService = inventoryService;
        this.sftpService = sftpService;
        this.xmlParser = xmlParser;
        this.planner = planner;
    }

    public void syncAllWarehouses() {
        if (!running.compareAndSet(false, true)) {
            log.warn("Skipping inventory sync because a previous run is still active");
            return;
        }

        try {
            Path workDirectory = Path.of(syncProperties.workDir()).toAbsolutePath().normalize();
            Files.createDirectories(workDirectory);
            Map<WarehouseRegion, String> locations = locationService.resolveRequiredLocations(false);
            Map<String, ShopifyVariant> skuMap = catalogService.buildSkuMap();

            for (WarehouseRegion warehouse : WarehouseRegion.values()) {
                syncWarehouse(warehouse, locations.get(warehouse), skuMap, workDirectory);
            }
        } catch (Exception e) {
            log.error("Inventory sync run failed unexpectedly", e);
        } finally {
            running.set(false);
        }
    }

    private void syncWarehouse(
            WarehouseRegion warehouse,
            String locationId,
            Map<String, ShopifyVariant> skuMap,
            Path workDirectory
    ) {
        try {
            List<RemoteInventoryFile> files = sftpService.listInventoryFiles(warehouse);
            log.info("Found SFTP inventory files warehouse={} count={}", warehouse, files.size());
            for (RemoteInventoryFile file : files) {
                processFile(file, locationId, skuMap, workDirectory);
            }
        } catch (Exception e) {
            log.error("Warehouse sync failed warehouse={}", warehouse, e);
        }
    }

    private void processFile(
            RemoteInventoryFile remoteFile,
            String locationId,
            Map<String, ShopifyVariant> skuMap,
            Path workDirectory
    ) {
        Path localFile = null;
        try {
            localFile = sftpService.download(remoteFile, workDirectory);
            ParseResult parsed = xmlParser.parse(localFile);
            final Path downloadedFile = localFile;
            PlanResult plan = planner.plan(parsed.records(), skuMap, remoteFile.warehouse(), locationId);

            log.info("Prepared file warehouse={} remote={} local={} records={} skipped={} updates={} missingSkus={} forcedZero={} duplicateXmlSkus={} policyWarnings={}",
                    remoteFile.warehouse(), remoteFile.remotePath(), localFile,
                    parsed.records().size(), parsed.skippedRecords(), plan.updates().size(),
                    plan.missingSkus().size(), plan.forcedZeroCount(), plan.duplicateXmlSkuCount(),
                    plan.policyWarnings().size());

            plan.missingSkus().forEach(sku -> log.warn(
                    "Missing Shopify SKU warehouse={} remote={} local={} sku={}",
                    remoteFile.warehouse(), remoteFile.remotePath(), downloadedFile, sku));
            plan.policyWarnings().forEach(warning -> log.warn(
                    "Metafield policy fallback warehouse={} remote={} local={} detail={}",
                    remoteFile.warehouse(), remoteFile.remotePath(), downloadedFile, warning));
            plan.updates().stream()
                    .filter(update -> update.quantity() == 0 && update.policyNote().startsWith("offline"))
                    .forEach(update -> log.info(
                            "Forced-zero SKU warehouse={} remote={} local={} sku={} inventoryItemId={} locationId={} metafield={} quantity=0",
                            update.warehouse(), remoteFile.remotePath(), downloadedFile, update.sku(),
                            update.inventoryItemId(), update.locationId(), update.metafieldValue()));

            boolean allBatchesSucceeded = sendBatches(remoteFile, localFile, plan.updates());
            if (!allBatchesSucceeded) {
                log.error("File processing incomplete; remote file will remain in place warehouse={} remote={} local={}",
                        remoteFile.warehouse(), remoteFile.remotePath(), localFile);
                return;
            }

            try {
                sftpService.moveToProcessed(remoteFile);
                Files.deleteIfExists(localFile);
                log.info("Processed file successfully warehouse={} remote={} local={}",
                        remoteFile.warehouse(), remoteFile.remotePath(), localFile);
            } catch (Exception moveError) {
                log.error("Remote move failed; local copy retained warehouse={} remote={} local={}",
                        remoteFile.warehouse(), remoteFile.remotePath(), localFile, moveError);
            }
        } catch (Exception e) {
            log.error("File processing failed; remote file not moved warehouse={} remote={} local={}",
                    remoteFile.warehouse(), remoteFile.remotePath(), localFile, e);
        }
    }

    private boolean sendBatches(RemoteInventoryFile remoteFile, Path localFile, List<InventoryUpdate> updates) {
        List<List<InventoryUpdate>> batches = BatchUtils.partition(updates, syncProperties.batchSize());
        boolean allSucceeded = true;

        for (int index = 0; index < batches.size(); index++) {
            List<InventoryUpdate> batch = batches.get(index);
            BatchOutcome outcome = inventoryService.setQuantities(
                    batch, remoteFile.warehouse(), remoteFile.remotePath(), index
            );
            if (!outcome.success()) {
                allSucceeded = false;
                log.error("Shopify batch failed warehouse={} remote={} local={} batchIndex={} batchSize={} requestId={} errors={}",
                        remoteFile.warehouse(), remoteFile.remotePath(), localFile, index, batch.size(),
                        outcome.requestId(), outcome.errors());
                for (InventoryUpdate update : batch) {
                    log.error("Failed batch context warehouse={} remote={} local={} sku={} inventoryItemId={} locationId={} quantity={} metafield={} policy={}",
                            update.warehouse(), remoteFile.remotePath(), localFile, update.sku(),
                            update.inventoryItemId(), update.locationId(), update.quantity(),
                            update.metafieldValue(), update.policyNote());
                }
            } else {
                log.info("Shopify batch succeeded warehouse={} remote={} batchIndex={} batchSize={} requestId={}",
                        remoteFile.warehouse(), remoteFile.remotePath(), index, batch.size(), outcome.requestId());
            }
        }
        return allSucceeded;
    }
}
