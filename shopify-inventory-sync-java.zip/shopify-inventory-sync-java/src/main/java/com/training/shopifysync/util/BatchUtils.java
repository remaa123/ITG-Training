package com.training.shopifysync.util;

import java.util.ArrayList;
import java.util.List;

public final class BatchUtils {
    private BatchUtils() {
    }

    public static <T> List<List<T>> partition(List<T> items, int size) {
        if (size < 1 || size > 250) {
            throw new IllegalArgumentException("Batch size must be between 1 and 250");
        }
        List<List<T>> result = new ArrayList<>();
        for (int start = 0; start < items.size(); start += size) {
            result.add(List.copyOf(items.subList(start, Math.min(start + size, items.size()))));
        }
        return result;
    }
}
