package com.training.shopifysync.domain;

public record ShopifyVariant(
        String variantId,
        String sku,
        String inventoryItemId,
        boolean tracked,
        String metafieldValue
) {
}
