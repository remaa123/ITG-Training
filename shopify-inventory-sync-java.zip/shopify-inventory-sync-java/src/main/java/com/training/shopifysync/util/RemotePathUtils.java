package com.training.shopifysync.util;

public final class RemotePathUtils {
    private RemotePathUtils() {
    }

    public static String join(String left, String right) {
        String cleanLeft = left.endsWith("/") ? left.substring(0, left.length() - 1) : left;
        String cleanRight = right.startsWith("/") ? right.substring(1) : right;
        return cleanLeft + "/" + cleanRight;
    }

    public static String processedDirectory(String sourceDirectory) {
        return join(sourceDirectory, "processed");
    }

    public static String processedFilePath(String sourceDirectory, String fileName) {
        return join(processedDirectory(sourceDirectory), fileName);
    }
}
