package com.training.shopifysync.domain;

public record PolicyDecision(boolean online, String note) {
}
