package com.training.shopifysync.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.shopifysync.domain.PolicyDecision;
import com.training.shopifysync.domain.WarehouseRegion;
import org.springframework.stereotype.Component;

@Component
public class VariantOnlinePolicy {
    private final ObjectMapper objectMapper;

    public VariantOnlinePolicy(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public PolicyDecision evaluate(String metafieldValue, WarehouseRegion region) {
        if (metafieldValue == null || metafieldValue.isBlank()) {
            return new PolicyDecision(true, "metafield missing; default online");
        }
        try {
            JsonNode root = objectMapper.readTree(metafieldValue);
            if (!root.isObject()) {
                return new PolicyDecision(true, "metafield is not a JSON object; default online");
            }
            JsonNode flag = root.get(region.metafieldKey());
            if (flag == null || flag.isNull()) {
                return new PolicyDecision(true, "regional key missing; default online");
            }
            if (!flag.isBoolean()) {
                return new PolicyDecision(true, "regional flag is not boolean; default online");
            }
            return new PolicyDecision(flag.asBoolean(), flag.asBoolean() ? "online" : "offline; force zero");
        } catch (Exception e) {
            return new PolicyDecision(true, "invalid JSON; default online");
        }
    }
}
