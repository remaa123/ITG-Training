package com.training.shopifysync.config;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "sync")
public record SyncProperties(
        @NotBlank String cron,
        @NotBlank String zone,
        @NotBlank String workDir,
        @Min(1) @Max(250) int batchSize
) {
}
