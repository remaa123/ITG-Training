package com.training.shopifysync.runner;

import com.training.shopifysync.service.InventorySyncService;
import com.training.shopifysync.service.ShopifyConnectionTestService;
import com.training.shopifysync.service.ShopifySetupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class ApplicationModeRunner implements ApplicationRunner {

    private static final Logger log =
            LoggerFactory.getLogger(ApplicationModeRunner.class);

    private final String mode;
    private final ShopifySetupService setupService;
    private final InventorySyncService syncService;
    private final ShopifyConnectionTestService connectionTestService;
    private final ConfigurableApplicationContext context;

    public ApplicationModeRunner(
            @Value("${app.mode:scheduler}") String mode,
            ShopifySetupService setupService,
            InventorySyncService syncService,
            ShopifyConnectionTestService connectionTestService,
            ConfigurableApplicationContext context
    ) {
        this.mode = mode;
        this.setupService = setupService;
        this.syncService = syncService;
        this.connectionTestService = connectionTestService;
        this.context = context;
    }

    @Override
    public void run(ApplicationArguments args) {

        String normalizedMode = mode == null
                ? ""
                : mode.trim().toLowerCase(Locale.ROOT);

        log.info("Application started with APP_MODE={}", normalizedMode);

        switch (normalizedMode) {

            case "connection-test" -> {
                log.info("Running Shopify connection test");
                connectionTestService.testConnection();
                log.info("Connection test finished successfully");
                context.close();
            }

            case "setup" -> {
                log.info("Running Shopify initial setup");
                setupService.runSetup();
                log.info("Shopify setup finished successfully");
                context.close();
            }

            case "sync-once" -> {
                log.info("Running one inventory synchronization");
                syncService.syncAllWarehouses();
                log.info("Inventory synchronization finished");
                context.close();
            }

            case "scheduler" ->
                    log.info("Scheduler mode is active. Waiting for scheduled sync runs.");

            default -> throw new IllegalArgumentException(
                    "Unsupported APP_MODE='" + mode
                            + "'. Use connection-test, setup, sync-once, or scheduler."
            );
        }
    }
}