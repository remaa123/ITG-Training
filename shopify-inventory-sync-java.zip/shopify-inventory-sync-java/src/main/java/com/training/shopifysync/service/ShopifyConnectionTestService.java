package com.training.shopifysync.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.training.shopifysync.domain.GraphQlResult;
import com.training.shopifysync.shopify.ShopifyGraphQlClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class ShopifyConnectionTestService {

    private static final Logger log =
            LoggerFactory.getLogger(ShopifyConnectionTestService.class);

    private static final String CONNECTION_TEST_QUERY = """
            query ConnectionTest {
              shop {
                name
                myshopifyDomain
              }

              locations(first: 50, includeInactive: true) {
                nodes {
                  id
                  name
                  isActive
                  fulfillsOnlineOrders
                }
              }
            }
            """;

    private final ShopifyGraphQlClient client;

    public ShopifyConnectionTestService(ShopifyGraphQlClient client) {
        this.client = client;
    }

    public void testConnection() {
        log.info("Starting Shopify connection test");

        GraphQlResult result =
                client.execute(CONNECTION_TEST_QUERY, Map.of());

        JsonNode shop = result.data().path("shop");

        log.info(
                "Connected successfully to Shopify shop name={} domain={} requestId={}",
                shop.path("name").asText(),
                shop.path("myshopifyDomain").asText(),
                result.requestId()
        );

        JsonNode locations =
                result.data().path("locations").path("nodes");

        log.info("Shopify locations found={}", locations.size());

        for (JsonNode location : locations) {
            log.info(
                    "Location name={} id={} active={} fulfillsOnlineOrders={}",
                    location.path("name").asText(),
                    location.path("id").asText(),
                    location.path("isActive").asBoolean(),
                    location.path("fulfillsOnlineOrders").asBoolean()
            );
        }

        log.info("Shopify connection test completed successfully");
    }
}