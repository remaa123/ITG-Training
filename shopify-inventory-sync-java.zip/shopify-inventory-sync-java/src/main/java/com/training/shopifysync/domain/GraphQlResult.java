package com.training.shopifysync.domain;

import com.fasterxml.jackson.databind.JsonNode;

public record GraphQlResult(JsonNode data, String requestId) {
}
