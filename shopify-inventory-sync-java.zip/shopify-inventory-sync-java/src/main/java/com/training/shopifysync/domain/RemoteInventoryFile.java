package com.training.shopifysync.domain;

public record RemoteInventoryFile(
        WarehouseRegion warehouse,
        String directory,
        String remotePath,
        String fileName,
        long modifiedTime
) {
}
