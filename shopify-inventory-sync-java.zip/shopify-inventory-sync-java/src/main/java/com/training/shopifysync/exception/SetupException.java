package com.training.shopifysync.exception;

public class SetupException extends RuntimeException {
    public SetupException(String message) {
        super(message);
    }

    public SetupException(String message, Throwable cause) {
        super(message, cause);
    }
}
