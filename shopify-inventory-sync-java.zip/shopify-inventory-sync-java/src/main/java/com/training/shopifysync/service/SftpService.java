package com.training.shopifysync.service;

import com.training.shopifysync.config.SftpProperties;
import com.training.shopifysync.domain.RemoteInventoryFile;
import com.training.shopifysync.domain.WarehouseRegion;
import com.training.shopifysync.util.RemotePathUtils;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.sftp.RemoteResourceInfo;
import net.schmizz.sshj.sftp.SFTPClient;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;

@Service
public class SftpService {
    private static final Logger log = LoggerFactory.getLogger(SftpService.class);
    private final SftpProperties properties;

    public SftpService(SftpProperties properties) {
        this.properties = properties;
    }

    public List<RemoteInventoryFile> listInventoryFiles(WarehouseRegion warehouse) throws Exception {
        String directory = requiredDirectory(warehouse);
        try (SSHClient ssh = connect(); SFTPClient sftp = ssh.newSFTPClient()) {
            return sftp.ls(directory).stream()
                    .filter(RemoteResourceInfo::isRegularFile)
                    .filter(file -> warehouse.matchesFileName(file.getName()))
                    .map(file -> new RemoteInventoryFile(
                            warehouse,
                            directory,
                            RemotePathUtils.join(directory, file.getName()),
                            file.getName(),
                            file.getAttributes().getMtime()
                    ))
                    .sorted(Comparator.comparing(RemoteInventoryFile::fileName))
                    .toList();
        }
    }

    public Path download(RemoteInventoryFile remoteFile, Path workDirectory) throws Exception {
        Path warehouseDirectory = workDirectory.resolve(remoteFile.warehouse().name().toLowerCase());
        Files.createDirectories(warehouseDirectory);
        Path localPath = warehouseDirectory.resolve(remoteFile.fileName());
        try (SSHClient ssh = connect(); SFTPClient sftp = ssh.newSFTPClient()) {
            sftp.get(remoteFile.remotePath(), localPath.toString());
        }
        log.info("Downloaded SFTP file warehouse={} remote={} local={}",
                remoteFile.warehouse(), remoteFile.remotePath(), localPath);
        return localPath;
    }

    public void moveToProcessed(RemoteInventoryFile remoteFile) throws Exception {
        String processedDirectory = RemotePathUtils.processedDirectory(remoteFile.directory());
        String destination = RemotePathUtils.processedFilePath(remoteFile.directory(), remoteFile.fileName());
        try (SSHClient ssh = connect(); SFTPClient sftp = ssh.newSFTPClient()) {
            sftp.mkdirs(processedDirectory);
            sftp.rename(remoteFile.remotePath(), destination);
        }
        log.info("Moved remote SFTP file to processed source={} destination={}",
                remoteFile.remotePath(), destination);
    }

    private SSHClient connect() throws Exception {
        if (properties.host() == null || properties.host().isBlank()) {
            throw new IllegalStateException(
                    "Missing SFTP_HOST. Configure SFTP credentials before running sync."
            );
        }

        if (properties.username() == null || properties.username().isBlank()) {
            throw new IllegalStateException(
                    "Missing SFTP_USERNAME. Configure SFTP credentials before running sync."
            );
        }

        SSHClient ssh = new SSHClient();
        if (properties.allowInsecureHostKey()) {
            log.warn("SFTP insecure host-key verification is enabled. Do not use this in production.");
            ssh.addHostKeyVerifier(new PromiscuousVerifier());
        } else if (properties.knownHostsPath() != null && !properties.knownHostsPath().isBlank()) {
            ssh.loadKnownHosts(new File(properties.knownHostsPath()));
        } else {
            ssh.loadKnownHosts();
        }

        ssh.connect(properties.host(), properties.port());
        if (properties.privateKeyPath() != null && !properties.privateKeyPath().isBlank()) {
            var keyProvider = properties.privateKeyPassphrase() == null || properties.privateKeyPassphrase().isBlank()
                    ? ssh.loadKeys(properties.privateKeyPath())
                    : ssh.loadKeys(properties.privateKeyPath(), properties.privateKeyPassphrase());
            ssh.authPublickey(properties.username(), keyProvider);
        } else {
            ssh.authPassword(properties.username(), properties.password());
        }
        return ssh;
    }

    private String requiredDirectory(WarehouseRegion warehouse) {
        String directory = properties.directories().get(warehouse);
        if (directory == null || directory.isBlank()) {
            throw new IllegalStateException("Missing SFTP directory for warehouse " + warehouse);
        }
        return directory;
    }

}
