package com.training.shopifysync.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.shopifysync.domain.WarehouseRegion;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VariantOnlinePolicyTest {
    private final VariantOnlinePolicy policy = new VariantOnlinePolicy(new ObjectMapper());

    @Test
    void missingAndInvalidMetafieldsDefaultOnline() {
        assertTrue(policy.evaluate(null, WarehouseRegion.US).online());
        assertTrue(policy.evaluate("not-json", WarehouseRegion.UK).online());
        assertTrue(policy.evaluate("{\"US\":true}", WarehouseRegion.UAE).online());
    }

    @Test
    void falseFlagForcesRegionOffline() {
        assertFalse(policy.evaluate("{\"UK\":false}", WarehouseRegion.UK).online());
    }

    @Test
    void euReadsDeretKey() {
        assertFalse(policy.evaluate("{\"Deret\":false}", WarehouseRegion.EU).online());
        assertTrue(policy.evaluate("{\"EU\":false}", WarehouseRegion.EU).online());
    }
}
