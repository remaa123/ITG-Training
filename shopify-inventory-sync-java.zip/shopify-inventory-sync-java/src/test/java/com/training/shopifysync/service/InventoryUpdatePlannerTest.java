package com.training.shopifysync.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.shopifysync.domain.InventoryRecord;
import com.training.shopifysync.domain.ShopifyVariant;
import com.training.shopifysync.domain.WarehouseRegion;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class InventoryUpdatePlannerTest {
    private final InventoryUpdatePlanner planner =
            new InventoryUpdatePlanner(new VariantOnlinePolicy(new ObjectMapper()));

    @Test
    void logsMissingSkuAndForcesOfflineVariantToZero() {
        ShopifyVariant variant = new ShopifyVariant(
                "gid://shopify/ProductVariant/1",
                "SKU-1",
                "gid://shopify/InventoryItem/1",
                true,
                "{\"US\":false}"
        );

        var result = planner.plan(
                List.of(new InventoryRecord("SKU-1", 20), new InventoryRecord("MISSING", 9)),
                Map.of("SKU-1", variant),
                WarehouseRegion.US,
                "gid://shopify/Location/1"
        );

        assertEquals(1, result.updates().size());
        assertEquals(0, result.updates().getFirst().quantity());
        assertEquals(1, result.forcedZeroCount());
        assertEquals(List.of("MISSING"), result.missingSkus());
    }

    @Test
    void lastDuplicateXmlSkuWins() {
        ShopifyVariant variant = new ShopifyVariant("v", "SKU-1", "i", true, null);
        var result = planner.plan(
                List.of(new InventoryRecord("SKU-1", 1), new InventoryRecord("SKU-1", 8)),
                Map.of("SKU-1", variant), WarehouseRegion.US, "l"
        );
        assertEquals(1, result.duplicateXmlSkuCount());
        assertEquals(8, result.updates().getFirst().quantity());
    }
}
