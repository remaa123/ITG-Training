package com.training.shopifysync.service;

import com.training.shopifysync.domain.ParseResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class XmlInventoryParserTest {

    @TempDir
    Path tempDir;

    private final XmlInventoryParser parser = new XmlInventoryParser();

    @Test
    void parsesNamespacedXmlAndNormalizesNegativeQuantity() throws Exception {
        Path file = tempDir.resolve("inventory.xml");

        Files.writeString(file, """
                <x:inventory xmlns:x="urn:test">
                  <x:record product-id="SKU-1">
                    <x:allocation>12</x:allocation>
                  </x:record>

                  <x:record product-id="SKU-2">
                    <x:allocation>-4</x:allocation>
                  </x:record>

                  <x:record product-id="">
                    <x:allocation>5</x:allocation>
                  </x:record>

                  <x:record product-id="SKU-3">
                    <x:allocation>bad</x:allocation>
                  </x:record>
                </x:inventory>
                """);

        ParseResult result = parser.parse(file);

        assertEquals(2, result.records().size());
        assertEquals(12, result.records().get(0).quantity());
        assertEquals(0, result.records().get(1).quantity());
        assertEquals(2, result.skippedRecords());
    }

    @Test
    void quantityNormalizationRejectsMissingOrFractionalValues() {
        assertTrue(parser.normalizeQuantity(null).isEmpty());
        assertTrue(parser.normalizeQuantity("").isEmpty());
        assertTrue(parser.normalizeQuantity("1.5").isEmpty());
        assertTrue(parser.normalizeQuantity("wrong").isEmpty());

        assertEquals(0, parser.normalizeQuantity("-1").orElseThrow());
        assertEquals(9, parser.normalizeQuantity(" 9 ").orElseThrow());
    }

    @Test
    void acceptsWholeNumberDecimals() {
        assertEquals(
                27,
                parser.normalizeQuantity("27.00").orElseThrow()
        );
    }

    @Test
    void rejectsFractionalInventory() {
        assertTrue(
                parser.normalizeQuantity("27.50").isEmpty()
        );
    }

    @Test
    void normalizesNegativeDecimalToZero() {
        assertEquals(
                0,
                parser.normalizeQuantity("-5.00").orElseThrow()
        );
    }

    @Test
    void parsesDoctorsNamespacedXmlExample() throws Exception {
        Path file = tempDir.resolve("huda-inventory.xml");

        Files.writeString(file, """
                <?xml version="1.0" encoding="utf-8"?>
                <inventory xmlns="http://www.demandware.com/xml/impex/inventory/2007-05-31">
                  <inventory-list>
                    <header list-id="huda-inventory">
                      <default-instock>false</default-instock>
                      <description>Inventory for Huda</description>
                      <use-bundle-inventory-only>false</use-bundle-inventory-only>
                    </header>

                    <records>
                      <record product-id="BW00001">
                        <allocation>27.00</allocation>
                        <allocation-timestamp>
                          2025-09-24T06:50:37
                        </allocation-timestamp>
                        <perpetual>false</perpetual>
                      </record>
                    </records>
                  </inventory-list>
                </inventory>
                """);

        ParseResult result = parser.parse(file);

        assertEquals(1, result.records().size());
        assertEquals("BW00001", result.records().get(0).sku());
        assertEquals(27, result.records().get(0).quantity());
        assertEquals(0, result.skippedRecords());
    }
}