package com.training.shopifysync.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RemotePathUtilsTest {
    @Test
    void buildsProcessedPathsWithoutDuplicateSlashes() {
        assertEquals("/sftp/us/processed", RemotePathUtils.processedDirectory("/sftp/us/"));
        assertEquals("/sftp/us/processed/file.xml",
                RemotePathUtils.processedFilePath("/sftp/us", "file.xml"));
    }
}
