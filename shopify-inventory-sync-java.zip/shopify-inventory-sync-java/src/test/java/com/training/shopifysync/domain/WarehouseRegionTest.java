package com.training.shopifysync.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WarehouseRegionTest {
    @Test
    void filtersFilesByExactWarehousePattern() {
        assertTrue(WarehouseRegion.US.matchesFileName("Huda_inv_full_us_20250917144737.xml"));
        assertTrue(WarehouseRegion.UK.matchesFileName("Huda_inv_full_uk_20250917144737.xml"));
        assertTrue(WarehouseRegion.UAE.matchesFileName("Huda_inv_full_20250917144737.xml"));
        assertTrue(WarehouseRegion.EU.matchesFileName("Huda_inv_full_dr_20250917144737.xml"));

        assertFalse(WarehouseRegion.UAE.matchesFileName("Huda_inv_full_us_20250917144737.xml"));
        assertFalse(WarehouseRegion.US.matchesFileName("Huda_inv_full_us_bad.xml"));
        assertFalse(WarehouseRegion.EU.matchesFileName("Huda_inv_full_dr_20250917144737.csv"));
    }

    @Test
    void euMapsToDeret() {
        assertEquals("Deret", WarehouseRegion.EU.metafieldKey());
    }
}
