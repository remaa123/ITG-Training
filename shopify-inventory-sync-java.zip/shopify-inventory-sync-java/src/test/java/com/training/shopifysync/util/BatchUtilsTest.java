package com.training.shopifysync.util;

import org.junit.jupiter.api.Test;

import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

class BatchUtilsTest {
    @Test
    void createsShopifySafeBatches() {
        var values = IntStream.range(0, 501).boxed().toList();
        var batches = BatchUtils.partition(values, 250);
        assertEquals(3, batches.size());
        assertEquals(250, batches.get(0).size());
        assertEquals(250, batches.get(1).size());
        assertEquals(1, batches.get(2).size());
    }

    @Test
    void rejectsBatchSizeAbove250() {
        assertThrows(IllegalArgumentException.class, () -> BatchUtils.partition(java.util.List.of(1), 251));
    }
}
