# Exact setup steps

## 1. Install / link the app

From this folder:

```bash
npm install -g @shopify/cli@latest
shopify app config link
```

When prompted, select the Shopify app you created for the training store.

If you do not have an app yet, use:

```bash
shopify app init
```

Choose an **extension-only** app, then replace its generated `shopify.app.toml` and `extensions/` with the files in this project.

## 2. Create metafield definitions

Create these merchant-editable definitions in Shopify Admin.

### Variant: max quantity

Resource: Product variant

- Namespace: `custom`
- Key: `max_order_quantity`
- Type: Integer
- Example: AB001 variant = `4`

### Shop: max distinct SKUs

Resource: Shop

- Namespace: `custom`
- Key: `max_distinct_skus`
- Type: Integer
- Example: `2`

### Shop: checkout gift collection handle

Resource: Shop

- Namespace: `custom`
- Key: `checkout_gift_collection_handle`
- Type: Single-line text
- Example: `checkout-gifts`

If this definition is accessed by the Checkout UI extension through Storefront API, give it Storefront API read access according to the current metafield-definition UI for your store.

### Shop: delivery rule configuration

Resource: Shop

- Namespace: `custom`
- Key: `delivery_customization_config`
- Type: JSON

Example value:

```json
{
  "countryCode": "US",
  "hiddenMethodTitle": "Express",
}
```

The project intentionally fixes the window to **15:00–16:00** in the Shopify shop timezone, matching the training requirement. The JSON only controls the country and delivery method title.

## 3. Configure variants

For every SKU/variant that has a limit, set `custom.max_order_quantity`.

Examples:

- AB001 = 4
- AB002 = 5
- AB003 = 2

A blank metafield means **no limit** for that variant.

## 4. Configure the gift collection

Create a collection with handle `checkout-gifts` (or set a different handle in `custom.checkout_gift_collection_handle`).

Put the variants/products that are allowed to appear in the checkout gift component into that collection.

Important: the Checkout UI Extension only adds the selected variant to the cart. It does **not** make it free. The missing Discount Function is intentionally outside this project.

## 5. Configure shipping in Admin

Go to:

Settings → Shipping and delivery → the relevant shipping profile → United States

Create two rates, for example:

- Standard
- Express

The delivery Function will hide the rate whose title matches `hiddenMethodTitle` between the configured times.

## 6. Generate Shopify Function types

After the app is linked:

```bash
shopify app function typegen
```

Do this whenever you change a function's GraphQL input query.

## 7. Run locally

```bash
shopify app dev
```

Use the Dev Console / preview URL to test the Checkout UI Extension and the theme extension.

## 8. Activate the validation rule

Shopify Admin → Settings → Checkout → Checkout Rules → Add rule.

Select **Gift Order Rules – Cart & Checkout Validation**, activate it, and save.

Errors from the validation function are exposed to the Storefront API cart and checkout. The included theme app block gives the cart a faster, user-friendly pre-check UX.

## 9. Activate delivery customization

Shopify Admin → Settings → Shipping and delivery → Delivery customizations → Add customization.

Select the deployed **Gift Order Rules – Delivery Customization** function and activate it.

## 10. Add the cart UX block

Online Store → Themes → Customize → Cart template / cart section → Add block → Apps.

Add **Cart quantity & SKU validation** and save.

This is UX only. The Function remains the server-side authority.

## 11. Add the checkout gift component

Open Checkout Editor and add the **Checkout gift selector** block at a suitable `purchase.checkout.block.render` location.

The extension requires Storefront API access because it queries the configured gift collection.

## 12. Test

### Quantity

- AB001 × 4 → allowed
- AB001 × 5 → blocked

### Distinct SKU count

With maximum = 2:

- AB001 + AB002 → allowed
- AB001 + AB002 + AB003 → blocked

### Shipping

- 14:59 → both rates visible
- 15:00 → configured hidden method hidden
- 15:30 → configured hidden method hidden
- 15:59 → configured hidden method hidden
- 16:00 → visible again

### Gift component

- Component loads
- Image and variant/product name render
- Add button adds the selected variant to the cart
- No free pricing is expected until the missing Discount Function is implemented
