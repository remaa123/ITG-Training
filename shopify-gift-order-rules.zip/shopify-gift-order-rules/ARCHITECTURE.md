# Architecture

```text
SHOPIFY APP
│
├── Configuration / Data
│   ├── Product Variant metafield: custom.max_order_quantity
│   ├── Shop metafield: custom.max_distinct_skus
│   ├── Shop metafield: custom.delivery_customization_config
│   └── Shop metafield: custom.checkout_gift_collection_handle
│
├── Business Logic (Shopify Functions)
│   ├── Cart & Checkout Validation Function
│   │   ├── max quantity per SKU
│   │   └── max number of distinct SKUs
│   │
│   └── Delivery Customization Function
│       └── hide configured US method 15:00–16:00
│
├── Storefront UI
│   └── Theme App Extension
│       └── fast client-side quantity/SKU warnings
│
└── Checkout UI
    └── Checkout UI Extension
        ├── query configured gift collection
        ├── show variant image/name
        └── add selected variant to cart
```

The missing Discount Function is intentionally outside this project. When added later, it should be responsible for the first-unit-free pricing rule; the checkout extension should remain responsible only for selecting/adding the gift variant.
