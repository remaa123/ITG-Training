// @ts-check

/**
 * @typedef {import("../generated/api").RunInput} RunInput
 * @typedef {import("../generated/api").RunResult} RunResult
 */

const CART_STEP = 'CART_INTERACTION';
const CHECKOUT_STEPS = new Set(['CHECKOUT_INTERACTION', 'CHECKOUT_COMPLETION']);

/**
 * @param {RunInput} input
 * @returns {boolean}
 */
function isCartInteraction(input) {
  return input.buyerJourney?.step === CART_STEP;
}

/**
 * @param {RunInput} input
 * @returns {boolean}
 */
function isCheckout(input) {
  return CHECKOUT_STEPS.has(input.buyerJourney?.step ?? '');
}

/**
 * @param {RunInput} input
 * @returns {RunResult}
 */
export function run(input) {
  // During ordinary cart interaction and checkout, enforce the same rules.
  // This keeps the Function authoritative while allowing different copy by surface.
  if (!isCartInteraction(input) && !isCheckout(input)) {
    return {operations: []};
  }

  const errors = [];
  const cartMessage = isCartInteraction(input);
  const maxDistinctSkus = Number.parseInt(input.shop.metafield?.value ?? '', 10);
  const distinctKeys = new Set();

  for (const line of input.cart.lines) {
    if (line.merchandise.__typename !== 'ProductVariant') continue;

    const variant = line.merchandise;
    const sku = variant.sku?.trim();
    const distinctKey = sku || variant.id;
    distinctKeys.add(distinctKey);

    const maxQty = Number.parseInt(variant.metafield?.value ?? '', 10);
    if (Number.isFinite(maxQty) && maxQty >= 0 && line.quantity > maxQty) {
      errors.push({
        message: cartMessage
          ? `You can only add up to ${maxQty} units of ${sku || variant.product.title} to your cart.`
          : `${sku || variant.product.title} exceeds the maximum allowed quantity of ${maxQty}.`,
        target: '$.cart',
      });
    }
  }

  if (Number.isFinite(maxDistinctSkus) && maxDistinctSkus >= 0 && distinctKeys.size > maxDistinctSkus) {
    errors.push({
      message: cartMessage
        ? `You can only have ${maxDistinctSkus} different SKUs in your cart.`
        : `Your cart contains ${distinctKeys.size} different SKUs. The maximum allowed is ${maxDistinctSkus}.`,
      target: '$.cart',
    });
  }

  if (errors.length === 0) return {operations: []};

  return {
    operations: [
      {
        validationAdd: {
          errors,
        },
      },
    ],
  };
}
