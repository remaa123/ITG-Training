import '@shopify/ui-extensions/preact';
import {render} from 'preact';
import {useEffect, useState} from 'preact/hooks';

const CONFIG_QUERY = `#graphql
  query GiftCollectionConfig {
    shop {
      metafield(namespace: "custom", key: "checkout_gift_collection_handle") {
        value
      }
    }
  }
`;

const GIFTS_QUERY = `#graphql
  query GiftCollection($handle: String!) {
    collection(handle: $handle) {
      title
      products(first: 20) {
        nodes {
          id
          title
          featuredImage {
            url
            altText
          }
          variants(first: 100) {
            nodes {
              id
              title
              availableForSale
              image {
                url
                altText
              }
            }
          }
        }
      }
    }
  }
`;

function getGiftsFromCollection(data) {
  return (data?.collection?.products?.nodes ?? []).flatMap((product) =>
    (product.variants?.nodes ?? []).map((variant) => ({
      id: variant.id,
      title: variant.title === 'Default Title' ? product.title : `${product.title} — ${variant.title}`,
      image: variant.image || product.featuredImage,
      availableForSale: variant.availableForSale,
    })),
  );
}

function Extension() {
  const [gifts, setGifts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const configResult = await shopify.query(CONFIG_QUERY, {version: '2026-07'});
        const handle = configResult?.data?.shop?.metafield?.value?.trim();
        if (!handle) return;

        const giftsResult = await shopify.query(GIFTS_QUERY, {
          variables: {handle},
          version: '2026-07',
        });

        if (!cancelled) {
          setGifts(getGiftsFromCollection(giftsResult.data));
        }
      } catch (error) {
        console.error('Failed to load checkout gifts', error);
        if (!cancelled) setMessage('Gift options could not be loaded.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  async function addGift(variantId) {
    setAdding(variantId);
    setMessage('');

    try {
      const result = await shopify.applyCartLinesChange({
        type: 'addCartLine',
        merchandiseId: variantId,
        quantity: 1,
      });

      if (result.type === 'error') {
        setMessage(result.message || 'The gift could not be added.');
      } else {
        setMessage('Gift added to your cart.');
      }
    } catch (error) {
      console.error('Failed to add gift', error);
      setMessage('The gift could not be added.');
    } finally {
      setAdding(null);
    }
  }

  if (loading) {
    return <s-text>Loading gift options…</s-text>;
  }

  if (gifts.length === 0) {
    return null;
  }

  return (
    <s-stack gap="base">
      <s-heading>Choose a free gift</s-heading>

      {message && <s-banner tone="info">{message}</s-banner>}

      <s-grid gridTemplateColumns="repeat(2, minmax(0, 1fr))" gap="base">
        {gifts.map((gift) => (
          <s-stack key={gift.id} gap="small">
            {gift.image?.url && (
              <s-image
                src={gift.image.url}
                alt={gift.image.altText || gift.title}
                aspectRatio="1/1"
                objectFit="cover"
                borderRadius="base"
                inlineSize="fill"
              />
            )}
            <s-text>{gift.title}</s-text>
            <s-text>Free gift</s-text>
            <s-button
              variant="secondary"
              loading={adding === gift.id}
              disabled={!gift.availableForSale || adding !== null}
              onClick={() => addGift(gift.id)}
            >
              {gift.availableForSale ? 'Add gift' : 'Unavailable'}
            </s-button>
          </s-stack>
        ))}
      </s-grid>
    </s-stack>
  );
}

export default function extension() {
  render(<Extension />, document.body);
}
