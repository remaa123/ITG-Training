// @ts-check

/**
 * @typedef {import("../generated/api").RunInput} RunInput
 * @typedef {import("../generated/api").RunResult} RunResult
 */

/**
 * @returns {{countryCode: string, hiddenMethodTitle: string, startTime: string, endTime: string}}
 */
function defaultConfig() {
  return {
    countryCode: 'US',
    hiddenMethodTitle: 'Express',
  };
}

/**
 * @param {RunInput} input
 * @returns {RunResult}
 */
export function run(input) {
  const configured = input.shop.metafield?.jsonValue;
  const config = configured && typeof configured === 'object'
    ? {...defaultConfig(), ...configured}
    : defaultConfig();

  // The project requirement is fixed to 15:00–16:00 in the shop timezone.
  // The Function API performs this comparison server-side.
  if (!input.shop.localTime.timeBetween) return {operations: []};

  const operations = [];

  for (const group of input.cart.deliveryGroups) {
    if (group.deliveryAddress?.countryCode !== config.countryCode) continue;

    for (const option of group.deliveryOptions ?? []) {
      if (option.title === config.hiddenMethodTitle) {
        operations.push({
          deliveryOptionHide: {
            deliveryOptionHandle: option.handle,
          },
        });
      }
    }
  }

  return {operations};
}
