# Shopify Gift + Order Rules Training App

This project implements the Shopify-native parts of the training project **except the Discount Function**.

Included:
- Cart & Checkout Validation Function
  - max quantity per SKU/variant via `custom.max_order_quantity`
  - max number of distinct SKUs via `shop.metafields.custom.max_distinct_skus`
  - different messages for cart interaction vs checkout
- Delivery Customization Function
  - US shipping rule
  - hides one configured delivery method between 15:00 and 16:00 in the shop timezone
  - configuration via `shop.metafields.custom.delivery_customization_config`
- Checkout UI Extension
  - reads a configured gift collection handle from `shop.metafields.custom.checkout_gift_collection_handle`
  - displays product/variant cards with name and image
  - adds the selected variant to the cart
  - **does not make it free**; the missing Discount Function is intentionally excluded
- Theme App Extension
  - storefront/cart UX for quantity-limit and distinct-SKU warnings
  - uses the same metafield configuration as the server-side validation

## Required Shopify setup

1. Create/link a Shopify CLI app.
2. Create the metafield definitions described in `SETUP.md`.
3. Put max quantity values on variants.
4. Put the global distinct SKU limit on the shop.
5. Put the shipping configuration on the shop.
6. Create a collection with handle `checkout-gifts` (or change the shop metafield to another handle) and publish the gift products.
7. Create two US shipping rates in Shopify Admin.
8. Run `shopify app function typegen` from the app root.
9. Run `shopify app dev` and install/preview the app on the dev store.
10. Activate the validation and delivery customization functions in Shopify Admin.
11. Add the Theme App Block to the cart template.
12. Add the Checkout UI Extension using Checkout Editor.

The Discount Function is deliberately not included in this repository.
