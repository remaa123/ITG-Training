package com.training.shopifysync.runner;

import com.training.shopifysync.service.InventorySyncService;
import com.training.shopifysync.service.ShopifySetupService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.DefaultApplicationArguments;
import org.springframework.context.ConfigurableApplicationContext;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

class ApplicationModeRunnerTest {

    private static DefaultApplicationArguments emptyArgs() {
        return new DefaultApplicationArguments(new String[0]);
    }

    @Test
    void setupModeRunsSetupAndClosesApplication() {
        ShopifySetupService setupService = mock(ShopifySetupService.class);
        InventorySyncService syncService = mock(InventorySyncService.class);
        ConfigurableApplicationContext context = mock(ConfigurableApplicationContext.class);

        ApplicationModeRunner runner = new ApplicationModeRunner("setup", setupService, syncService, context);
        runner.run(emptyArgs());

        verify(setupService).runSetup();
        verify(syncService, never()).syncAllWarehouses();
        verify(context).close();
    }

    @Test
    void syncOnceModeRunsSyncAndClosesApplication() {
        ShopifySetupService setupService = mock(ShopifySetupService.class);
        InventorySyncService syncService = mock(InventorySyncService.class);
        ConfigurableApplicationContext context = mock(ConfigurableApplicationContext.class);

        ApplicationModeRunner runner = new ApplicationModeRunner("sync-once", setupService, syncService, context);
        runner.run(emptyArgs());

        verify(setupService, never()).runSetup();
        verify(syncService).syncAllWarehouses();
        verify(context).close();
    }

    @Test
    void schedulerModeKeepsApplicationRunning() {
        ShopifySetupService setupService = mock(ShopifySetupService.class);
        InventorySyncService syncService = mock(InventorySyncService.class);
        ConfigurableApplicationContext context = mock(ConfigurableApplicationContext.class);

        ApplicationModeRunner runner = new ApplicationModeRunner("scheduler", setupService, syncService, context);
        runner.run(emptyArgs());

        verifyNoInteractions(setupService);
        verifyNoInteractions(syncService);
        verify(context, never()).close();
    }

    @Test
    void invalidModeThrowsError() {
        ShopifySetupService setupService = mock(ShopifySetupService.class);
        InventorySyncService syncService = mock(InventorySyncService.class);
        ConfigurableApplicationContext context = mock(ConfigurableApplicationContext.class);

        ApplicationModeRunner runner = new ApplicationModeRunner("wrong", setupService, syncService, context);

        assertThrows(IllegalArgumentException.class, () -> runner.run(emptyArgs()));
        verifyNoInteractions(setupService);
        verifyNoInteractions(syncService);
        verify(context, never()).close();
    }
}
