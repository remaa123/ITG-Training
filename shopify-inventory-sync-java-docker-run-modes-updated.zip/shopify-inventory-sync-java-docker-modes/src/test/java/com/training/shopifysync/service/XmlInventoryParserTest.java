package com.training.shopifysync.service;

import com.training.shopifysync.domain.ParseResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class XmlInventoryParserTest {
    @TempDir Path tempDir;

    private final XmlInventoryParser parser = new XmlInventoryParser();

    @Test
    void parsesNamespacedXmlAndNormalizesNegativeQuantity() throws Exception {
        Path file = tempDir.resolve("inventory.xml");
        Files.writeString(file, """
                <x:inventory xmlns:x="urn:test">
                  <x:record product-id="SKU-1"><x:allocation>12</x:allocation></x:record>
                  <x:record product-id="SKU-2"><x:allocation>-4</x:allocation></x:record>
                  <x:record product-id=""><x:allocation>5</x:allocation></x:record>
                  <x:record product-id="SKU-3"><x:allocation>bad</x:allocation></x:record>
                </x:inventory>
                """);

        ParseResult result = parser.parse(file);
        assertEquals(2, result.records().size());
        assertEquals(12, result.records().get(0).quantity());
        assertEquals(0, result.records().get(1).quantity());
        assertEquals(2, result.skippedRecords());
    }

    @Test
    void quantityNormalizationRejectsMissingOrNonIntegerValues() {
        assertTrue(parser.normalizeQuantity(null).isEmpty());
        assertTrue(parser.normalizeQuantity("1.5").isEmpty());
        assertEquals(0, parser.normalizeQuantity("-1").orElseThrow());
        assertEquals(9, parser.normalizeQuantity(" 9 ").orElseThrow());
    }
}
