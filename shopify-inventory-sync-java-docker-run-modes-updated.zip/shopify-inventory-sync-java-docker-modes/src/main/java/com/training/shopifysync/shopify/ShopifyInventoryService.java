package com.training.shopifysync.shopify;

import com.fasterxml.jackson.databind.JsonNode;
import com.training.shopifysync.domain.BatchOutcome;
import com.training.shopifysync.domain.GraphQlResult;
import com.training.shopifysync.domain.InventoryUpdate;
import com.training.shopifysync.domain.ShopifyVariant;
import com.training.shopifysync.domain.WarehouseRegion;
import com.training.shopifysync.exception.SetupException;
import com.training.shopifysync.util.IdempotencyKeys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
@Service
public class ShopifyInventoryService {
    private static final Logger log = LoggerFactory.getLogger(ShopifyInventoryService.class);

    private static final String UPDATE_TRACKING = """
            mutation TrackInventory($id: ID!, $input: InventoryItemInput!) {
              inventoryItemUpdate(id: $id, input: $input) {
                inventoryItem { id tracked }
                userErrors { field message }
              }
            }
            """;

    private static final String ACTIVATE_AT_LOCATIONS = """
            mutation ActivateInventory($inventoryItemId: ID!, $updates: [InventoryBulkToggleActivationInput!]!) {
              inventoryBulkToggleActivation(inventoryItemId: $inventoryItemId, inventoryItemUpdates: $updates) {
                inventoryItem { id }
                userErrors { field message code }
              }
            }
            """;

    private static final String SET_QUANTITIES = """
            mutation SetInventory($input: InventorySetQuantitiesInput!, $idempotencyKey: String!) {
              inventorySetQuantities(input: $input) @idempotent(key: $idempotencyKey) {
                inventoryAdjustmentGroup { createdAt reason referenceDocumentUri }
                userErrors { field message code }
              }
            }
            """;

    private final ShopifyGraphQlClient client;

    public ShopifyInventoryService(ShopifyGraphQlClient client) {
        this.client = client;
    }

    public void ensureTrackedAndActivated(
            List<ShopifyVariant> variants,
            Map<WarehouseRegion, String> locationIds
    ) {
        int trackedChanged = 0;
        int activated = 0;
        for (ShopifyVariant variant : variants) {
            if (!variant.tracked()) {
                GraphQlResult response = client.execute(UPDATE_TRACKING, Map.of(
                        "id", variant.inventoryItemId(),
                        "input", Map.of("tracked", true)
                ));
                assertNoErrors(response, "inventoryItemUpdate", variant.sku());
                trackedChanged++;
            }

            List<Map<String, Object>> updates = locationIds.values().stream()
                    .map(locationId -> Map.<String, Object>of("locationId", locationId, "activate", true))
                    .toList();
            GraphQlResult response = client.execute(ACTIVATE_AT_LOCATIONS, Map.of(
                    "inventoryItemId", variant.inventoryItemId(),
                    "updates", updates
            ));
            assertNoErrors(response, "inventoryBulkToggleActivation", variant.sku());
            activated++;
        }
        log.info("Inventory setup complete variants={} trackingEnabled={} activationCalls={}",
                variants.size(), trackedChanged, activated);
    }

    public BatchOutcome setQuantities(
            List<InventoryUpdate> updates,
            WarehouseRegion warehouse,
            String remotePath,
            int batchIndex
    ) {
        List<Map<String, Object>> quantities = updates.stream()
                .map(update -> {
                    Map<String, Object> quantity = new HashMap<>();
                    quantity.put("inventoryItemId", update.inventoryItemId());
                    quantity.put("locationId", update.locationId());
                    quantity.put("quantity", update.quantity());

                    // Required by Shopify InventoryQuantityInput.
                    // null means skip compare-and-swap check.
                    quantity.put("changeFromQuantity", null);

                    return quantity;
                })
                .toList();

        String idempotencyKey = IdempotencyKeys.forInventoryBatch(
                warehouse.name(),
                remotePath,
                batchIndex
        );

        Map<String, Object> input = new HashMap<>();
        input.put("name", "available");
        input.put("reason", "correction");
        input.put("referenceDocumentUri", "gid://warehouse-feed/InventorySync/" + idempotencyKey);
        input.put("quantities", quantities);

        try {
            GraphQlResult response = client.execute(SET_QUANTITIES, Map.of(
                    "input", input,
                    "idempotencyKey", idempotencyKey
            ));

            JsonNode errors = response.data()
                    .path("inventorySetQuantities")
                    .path("userErrors");

            if (errors.isArray() && !errors.isEmpty()) {
                List<String> messages = new ArrayList<>();
                errors.forEach(error -> messages.add(error.toString()));
                return new BatchOutcome(false, response.requestId(), messages);
            }

            return new BatchOutcome(true, response.requestId(), List.of());
        } catch (Exception e) {
            return new BatchOutcome(false, "unknown", List.of(e.getMessage()));
        }
    }
    private void assertNoErrors(GraphQlResult response, String payloadName, String sku) {
        JsonNode errors = response.data().path(payloadName).path("userErrors");
        if (errors.isArray() && !errors.isEmpty()) {
            throw new SetupException("Shopify setup failed payload=" + payloadName + " sku=" + sku
                    + " errors=" + errors + " requestId=" + response.requestId());
        }
    }
}
