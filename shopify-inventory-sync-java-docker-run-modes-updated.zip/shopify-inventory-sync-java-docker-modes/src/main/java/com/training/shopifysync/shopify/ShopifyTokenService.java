package com.training.shopifysync.shopify;

import com.training.shopifysync.config.ShopifyProperties;
import org.springframework.stereotype.Service;

@Service
public class ShopifyTokenService {
    private final ShopifyProperties properties;

    public ShopifyTokenService(ShopifyProperties properties) {
        this.properties = properties;
    }

    public String getAccessToken() {
        return properties.offlineAccessToken();
    }
}
