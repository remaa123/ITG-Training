package com.training.shopifysync.runner;

import com.training.shopifysync.service.InventorySyncService;
import com.training.shopifysync.service.ShopifySetupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class ApplicationModeRunner implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(ApplicationModeRunner.class);

    private final String mode;
    private final ShopifySetupService setupService;
    private final InventorySyncService syncService;
    private final ConfigurableApplicationContext context;

    public ApplicationModeRunner(
            @Value("${app.mode:scheduler}") String mode,
            ShopifySetupService setupService,
            InventorySyncService syncService,
            ConfigurableApplicationContext context
    ) {
        this.mode = mode;
        this.setupService = setupService;
        this.syncService = syncService;
        this.context = context;
    }

    @Override
    public void run(ApplicationArguments args) {
        switch (mode.toLowerCase()) {
            case "setup" -> {
                setupService.runSetup();
                context.close();
            }
            case "sync-once" -> {
                syncService.syncAllWarehouses();
                context.close();
            }
            case "scheduler" -> log.info("Scheduler mode active");
            default -> throw new IllegalArgumentException(
                    "Unsupported APP_MODE='" + mode + "'. Use setup, sync-once, or scheduler."
            );
        }
    }
}
