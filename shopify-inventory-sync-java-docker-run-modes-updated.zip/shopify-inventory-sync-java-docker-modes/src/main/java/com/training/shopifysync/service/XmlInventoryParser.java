package com.training.shopifysync.service;

import com.training.shopifysync.domain.InventoryRecord;
import com.training.shopifysync.domain.ParseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;

@Component
public class XmlInventoryParser {
    private static final Logger log = LoggerFactory.getLogger(XmlInventoryParser.class);

    public ParseResult parse(Path file) throws Exception {
        XMLInputFactory factory = XMLInputFactory.newFactory();
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        factory.setProperty("javax.xml.stream.isSupportingExternalEntities", false);

        List<InventoryRecord> records = new ArrayList<>();
        int skipped = 0;
        String currentSku = null;
        String currentAllocation = null;
        boolean insideRecord = false;

        try (InputStream input = Files.newInputStream(file)) {
            XMLStreamReader reader = factory.createXMLStreamReader(input);
            while (reader.hasNext()) {
                int event = reader.next();
                if (event == XMLStreamConstants.START_ELEMENT) {
                    String localName = reader.getLocalName();
                    if ("record".equals(localName)) {
                        insideRecord = true;
                        currentSku = attributeByLocalName(reader, "product-id");
                        currentAllocation = null;
                    } else if (insideRecord && "allocation".equals(localName)) {
                        currentAllocation = reader.getElementText();
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT
                        && insideRecord && "record".equals(reader.getLocalName())) {
                    OptionalInt quantity = normalizeQuantity(currentAllocation);
                    if (currentSku == null || currentSku.isBlank() || quantity.isEmpty()) {
                        skipped++;
                        log.warn("Skipping invalid XML record file={} sku={} allocation={}",
                                file, currentSku, currentAllocation);
                    } else {
                        records.add(new InventoryRecord(currentSku.trim(), quantity.getAsInt()));
                    }
                    insideRecord = false;
                    currentSku = null;
                    currentAllocation = null;
                }
            }
            reader.close();
        }
        return new ParseResult(List.copyOf(records), skipped);
    }

    public OptionalInt normalizeQuantity(String rawAllocation) {
        if (rawAllocation == null || rawAllocation.isBlank()) {
            return OptionalInt.empty();
        }

        try {
            BigDecimal value = new BigDecimal(rawAllocation.trim());

            int quantity = value.intValueExact();

            return OptionalInt.of(Math.max(quantity, 0));
        } catch (ArithmeticException | NumberFormatException ex) {
            return OptionalInt.empty();
        }
    }
    private String attributeByLocalName(XMLStreamReader reader, String expected) {
        for (int i = 0; i < reader.getAttributeCount(); i++) {
            if (expected.equals(reader.getAttributeLocalName(i))) {
                return reader.getAttributeValue(i);
            }
        }
        return null;
    }
}
