param(
    [ValidateSet("setup", "sync-once", "scheduler")]
    [string]$Mode = "sync-once",

    [string]$Image = "shopify-inventory-sync:latest",
    [string]$EnvFile = ".env",
    [string]$ContainerName = "shopify-sync",
    [switch]$NoVolume
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $EnvFile)) {
    throw "Missing $EnvFile. Copy .env.example to .env and fill your real values first."
}

$runArgs = @("run")

if ($Mode -eq "scheduler") {
    $runArgs += @("-d", "--name", $ContainerName, "--restart", "unless-stopped")
} else {
    $runArgs += @("--rm")
}

$runArgs += @("--env-file", $EnvFile, "-e", "APP_MODE=$Mode", "-e", "SYNC_WORK_DIR=/app/work")

if (-not $NoVolume) {
    $workDir = Join-Path (Get-Location) "work"
    New-Item -ItemType Directory -Force -Path $workDir | Out-Null
    $runArgs += @("-v", "$($workDir):/app/work")
}

$runArgs += @($Image)

Write-Host "Running Docker mode: $Mode"
docker @runArgs
