# Build image
./scripts/docker-build.ps1

# Run one-time Shopify setup, then container exits.
docker run --rm --env-file .env -e APP_MODE=setup shopify-inventory-sync:latest

# Run one inventory sync, then container exits.
docker run --rm --env-file .env -e APP_MODE=sync-once shopify-inventory-sync:latest

# Run sync-once with a local work folder mounted into the container.
docker run --rm --env-file .env -e APP_MODE=sync-once -e SYNC_WORK_DIR=/app/work -v "${PWD}/work:/app/work" shopify-inventory-sync:latest

# Run scheduler in detached mode as a named container.
docker run -d --name shopify-sync --restart unless-stopped --env-file .env -e APP_MODE=scheduler -e SYNC_WORK_DIR=/app/work -v "${PWD}/work:/app/work" shopify-inventory-sync:latest

# View scheduler logs.
docker logs -f shopify-sync

# Stop and remove scheduler container.
docker stop shopify-sync
docker rm shopify-sync

# Test the invalid APP_MODE branch. This should fail with "Unsupported APP_MODE".
docker run --rm --env-file .env -e APP_MODE=wrong shopify-inventory-sync:latest

# Open a shell inside the image for inspection.
docker run --rm --entrypoint sh shopify-inventory-sync:latest

# Limit container resources for testing.
docker run --rm --memory=512m --cpus=1 --env-file .env -e APP_MODE=sync-once shopify-inventory-sync:latest
