param(
    [string]$ImageName = "shopify-inventory-sync",
    [string]$Tag = "latest"
)

$ErrorActionPreference = "Stop"

Write-Host "Building Docker image: $ImageName:$Tag"
docker build -t "$ImageName:$Tag" .
