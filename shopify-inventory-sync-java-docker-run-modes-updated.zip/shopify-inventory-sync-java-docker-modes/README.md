# Shopify Inventory Sync (Java / Spring Boot)

A background service that reads warehouse inventory XML files from SFTP and sets absolute Shopify inventory quantities at four Shopify locations: **US, UK, UAE, and EU**.

## 1. What this service uses

- Java 21
- Spring Boot 4.1
- Maven
- Shopify GraphQL Admin API `2026-04`
- One offline Shopify Admin API access token stored in `SHOPIFY_ACCESS_TOKEN`
- SSHJ for SFTP
- StAX for namespace-aware streaming XML parsing
- JUnit 5 tests

This is **not** a Storefront API or Hydrogen task. It is a server-side Admin API integration.

## 2. Shopify authentication update

The service no longer exchanges `SHOPIFY_CLIENT_ID` and `SHOPIFY_CLIENT_SECRET` for 24-hour tokens at runtime.

Runtime authentication now uses only:

```env
SHOPIFY_SHOP=your-store.myshopify.com
SHOPIFY_ACCESS_TOKEN=shpat_your_offline_admin_api_access_token
SHOPIFY_API_VERSION=2026-04
```

The access token should be obtained once through Shopify app installation / OAuth as an **offline Admin API access token**, then stored securely as an environment variable. Do not commit `.env`.

Required scopes for the token:

```text
read_products
write_products
read_inventory
write_inventory
read_locations
write_locations
```

## 3. Why offline token?

This project is a background inventory job. It runs hourly without a logged-in Shopify user. An offline Admin API token is tied to the shop/app installation and is appropriate for background jobs. The code simply sends the token in `X-Shopify-Access-Token` for every GraphQL Admin API request.

## 4. Catalog prerequisite

Before running `APP_MODE=setup`, import approximately 500 variants through Shopify Admin > Products > Import.

Rules:

- Every variant SKU must exactly equal the XML `product-id`.
- SKU values must be unique.
- Set inventory tracking to Shopify.
- Use a placeholder title if catalog content is unavailable.
- Variant metafields are applied by this service after import, not by the standard product CSV.

## 5. Configure

```bash
cp .env.example .env
```

Fill all required values. Never commit `.env`.

For SFTP host verification, provide `SFTP_KNOWN_HOSTS_PATH`. Only use `SFTP_ALLOW_INSECURE_HOST_KEY=true` against a local test server.

## 6. Run

```bash
mvn test
mvn spring-boot:run
```

### Setup mode

```env
APP_MODE=setup
```

It will:

1. Resolve or create the four Shopify locations.
2. Create the variant JSON metafield definition.
3. Load variants and build the SKU map.
4. Apply the default all-online metafield when it is missing.
5. Enable inventory tracking when needed.
6. Activate every inventory item at all four locations.

### One manual sync

```env
APP_MODE=sync-once
```

### Hourly scheduler

```env
APP_MODE=scheduler
SYNC_CRON=0 0 * * * *
```

## 7. File processing sequence

For every warehouse:

1. List only files matching the exact warehouse filename regex.
2. Sort files by timestamped filename.
3. Download a remote file to the local work directory.
4. Parse `product-id` and `allocation` using namespace-aware XML parsing.
5. Normalize negative quantities to zero and skip invalid records.
6. Match XML SKU to Shopify InventoryItem.
7. Apply the regional metafield policy (`EU` reads `Deret`).
8. Send absolute `available` quantities in batches of at most 250.
9. Continue later batches even when one batch fails.
10. Move the remote file to `<source>/processed/` only if every batch for that file succeeds.
11. Delete the local copy only after the remote move succeeds.

The service never deletes a remote SFTP file.

## 8. Important production note

`inventorySetQuantities` is correct here because the warehouse feed is the inventory source of truth. The implementation uses absolute quantities, so only one scheduler instance should run at a time. The in-process lock prevents overlap in one JVM. If deployed as multiple replicas, add a distributed lock or run exactly one replica.

## 9. Tests included

- SFTP filename filtering
- processed-file path handling
- namespace-aware XML parsing
- quantity normalization
- warehouse mapping and EU-to-Deret mapping
- missing/invalid metafield defaults
- offline forced-zero behavior
- 250-item batching
- missing-SKU handling
- duplicate XML SKU behavior

## 10. Docker and run modes

The project can also run inside Docker using the same application modes.

Build the image:

```powershell
docker build -t shopify-inventory-sync:latest .
```

Run setup mode:

```powershell
docker run --rm --env-file .env -e APP_MODE=setup shopify-inventory-sync:latest
```

Run one sync and exit:

```powershell
docker run --rm --env-file .env -e APP_MODE=sync-once shopify-inventory-sync:latest
```

Run scheduler in the background:

```powershell
docker run -d --name shopify-sync --restart unless-stopped --env-file .env -e APP_MODE=scheduler -e SYNC_WORK_DIR=/app/work -v "${PWD}/work:/app/work" shopify-inventory-sync:latest
```

View scheduler logs:

```powershell
docker logs -f shopify-sync
```

Stop and remove scheduler:

```powershell
docker stop shopify-sync
docker rm shopify-sync
```

More details are documented in `docs/docker-run-modes.md`.

## 11. Docker Compose shortcuts

```powershell
docker compose --profile setup up --build
```

```powershell
docker compose --profile sync-once up --build
```

```powershell
docker compose --profile scheduler up -d --build
```

The Compose file keeps the long Docker run options in one place, including the env file, mounted work directory, restart policy, and selected `APP_MODE`.
