# Docker Run Modes and Command Options

This project can run in three modes through the same Docker image. The mode is selected by the `APP_MODE` environment variable.

## 1. Build the image

```powershell
docker build -t shopify-inventory-sync:latest .
```

This reads the `Dockerfile`, builds the Spring Boot jar in the Maven stage, then creates a runtime image containing only Java and the final jar.

## 2. Setup mode

```powershell
docker run --rm --env-file .env -e APP_MODE=setup shopify-inventory-sync:latest
```

Use this when Shopify needs initial setup. It resolves or creates locations, creates the metafield definition, applies default metafields, and activates inventory items at the warehouse locations. The container exits when setup finishes.

## 3. Sync-once mode

```powershell
docker run --rm --env-file .env -e APP_MODE=sync-once shopify-inventory-sync:latest
```

Use this for a manual inventory sync. It reads XML files from SFTP, updates Shopify inventory, moves processed files, then exits.

## 4. Sync-once with mounted work directory

```powershell
docker run --rm --env-file .env -e APP_MODE=sync-once -e SYNC_WORK_DIR=/app/work -v "${PWD}/work:/app/work" shopify-inventory-sync:latest
```

This keeps downloaded temporary files visible on the host machine under `work/`. It is useful while testing and debugging.

## 5. Scheduler mode

```powershell
docker run -d --name shopify-sync --restart unless-stopped --env-file .env -e APP_MODE=scheduler -e SYNC_WORK_DIR=/app/work -v "${PWD}/work:/app/work" shopify-inventory-sync:latest
```

Use this when the service should stay running. Spring reads `SYNC_CRON` and runs the sync on schedule. The container keeps running in the background.

## 6. Useful Docker run options

| Option | Meaning in this project |
|---|---|
| `--rm` | Deletes the container after it exits. Best for `setup` and `sync-once`. |
| `-d` | Detached/background mode. Best for `scheduler`. |
| `--name shopify-sync` | Gives the running container a stable name for logs, stop, and remove commands. |
| `--restart unless-stopped` | Restarts the scheduler container after Docker/PC/server restarts unless manually stopped. |
| `--env-file .env` | Loads Shopify, SFTP, and sync settings from `.env` without copying secrets into the image. |
| `-e APP_MODE=...` | Overrides one environment variable from the command. Used to choose the code branch. |
| `-v "${PWD}/work:/app/work"` | Mounts a local folder into the container. Useful for temporary downloaded XML files. |
| `--entrypoint sh` | Opens a shell instead of running the Spring app. Useful for inspecting the image. |
| `--memory=512m` | Limits memory for testing. |
| `--cpus=1` | Limits CPU for testing. |

## 7. Testing mode branches from commands

The `ApplicationModeRunner` code has these branches:

- `APP_MODE=setup` calls `ShopifySetupService.runSetup()` and exits.
- `APP_MODE=sync-once` calls `InventorySyncService.syncAllWarehouses()` and exits.
- `APP_MODE=scheduler` keeps Spring running and allows `@Scheduled` to run by cron.
- Any other value throws an error.

Commands to test them:

```powershell
docker run --rm --env-file .env -e APP_MODE=setup shopify-inventory-sync:latest
```

```powershell
docker run --rm --env-file .env -e APP_MODE=sync-once shopify-inventory-sync:latest
```

```powershell
docker run -d --name shopify-sync --env-file .env -e APP_MODE=scheduler shopify-inventory-sync:latest
```

```powershell
docker run --rm --env-file .env -e APP_MODE=wrong shopify-inventory-sync:latest
```

The last command is intentionally wrong and should print an unsupported mode error. This confirms that the default branch is protected.

## 8. Docker Compose alternatives

```powershell
docker compose --profile setup up --build
```

```powershell
docker compose --profile sync-once up --build
```

```powershell
docker compose --profile scheduler up -d --build
```

```powershell
docker compose --profile scheduler logs -f
```

```powershell
docker compose --profile scheduler down
```

Compose is easier when the command becomes long because the env file, volume, restart policy, and mode are saved in `docker-compose.yml`.
